class Validate {
    constructor () {
        
    }

    async make(params){

    }
}

module.exports = Validate